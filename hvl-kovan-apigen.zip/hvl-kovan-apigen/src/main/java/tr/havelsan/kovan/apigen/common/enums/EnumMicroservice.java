package tr.havelsan.kovan.apigen.common.enums;

public enum EnumMicroservice {

    LOGISTIC_GENERAL,
    MATERIAL_MANAGEMENT,
    MAINTENANCE_MANAGEMENT,
    PRODUCTION,
    QUALITY,
    SALES,
    PROGRESS;
}
