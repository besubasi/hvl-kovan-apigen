package tr.havelsan.kovan.apigen.common.constant;

public interface CommonConstant {

    String USER_NAME_KEY = "user.name";


}
