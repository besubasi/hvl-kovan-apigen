import { Component, OnInit } from '@angular/core';
import { MenuItem, PrimeNGConfig } from 'primeng/api';

import { UiTranslateLoaderService } from 'ui-shared';

@Component({
    selector: 'apigen-main',
    templateUrl: './apigen-main.component.html',
})
export class ApigenMainComponent implements OnInit {
    constructor(protected translateService: UiTranslateLoaderService, private primengConfig: PrimeNGConfig) {
        this.translateService = translateService;
        this.primengConfig = primengConfig;
    }

    gfg: MenuItem[];

    ngOnInit(): void {
        this.gfg = [
            {
                label: 'HTML',
                items: [
                    {
                        label: 'HTML 1',
                    },
                    {
                        label: 'HTML 2',
                    },
                ],
            },
            {
                label: 'Angular',

                items: [
                    {
                        label: 'Angular 1',
                    },
                    {
                        label: 'Angular 2',
                    },
                ],
            },
        ];

        this.translateService.get('kovan.primeng').subscribe((res) => {
            this.primengConfig.setTranslation(res);
        });
    }
}
