import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrimengSharedModule } from '@hvlng/framework-core/shared';
import { ToolbarModule } from 'primeng/toolbar';
import { TableModule } from 'primeng/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'primeng/api';
import { HvlFormItemModule, HvlFormMessageModule, HvlMlDropdownModule } from '@hvlng/framework-core/form';
import { RxTranslateModule } from '@rxweb/translate';
import { DropdownModule } from 'primeng/dropdown';
import { ToastModule } from 'primeng/toast';
import { TranslateModule } from '@ngx-translate/core';
import { AccordionModule } from 'primeng/accordion';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DividerModule } from 'primeng/divider';

import { UiSharedModule } from 'ui-shared';

import { ApiGeneratorComponent } from '@apigen/module/apigen/generator/api-generator/component/api-generator.component';
import { ApiGeneratorRoutingModule } from '@apigen/module/apigen/generator/api-generator/api-generator-routing.module';

@NgModule({
    declarations: [ApiGeneratorComponent],
    imports: [
        CommonModule,
        ApiGeneratorRoutingModule,
        PrimengSharedModule,
        ToolbarModule,
        TableModule,
        FormsModule,
        SharedModule,
        ReactiveFormsModule,
        HvlFormMessageModule,
        HvlFormItemModule,
        RxTranslateModule,
        DropdownModule,
        UiSharedModule,
        HvlMlDropdownModule,
        ToastModule,
        TranslateModule,
        AccordionModule,
        RadioButtonModule,
        DividerModule,
    ],
})
export class ApiGeneratorModule {}
