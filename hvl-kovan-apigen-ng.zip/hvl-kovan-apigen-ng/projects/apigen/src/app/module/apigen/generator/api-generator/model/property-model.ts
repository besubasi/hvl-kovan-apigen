import { JsonObject, JsonProperty } from 'json2typescript';
import { EmptyControl, Required } from '@hvlng/framework-bff/core';

@JsonObject('PropertyModel')
export class PropertyModel {
    @Required()
    @JsonProperty('type', String)
    type: string;

    @Required()
    @JsonProperty('name', String)
    name: string = null;

    @Required()
    @JsonProperty('dbName', String)
    dbName: string = null;

    @EmptyControl()
    @JsonProperty('notNull', Boolean)
    notNull: boolean = false;

    @EmptyControl()
    @JsonProperty('useQueryParameter', Boolean)
    useQueryParameter: boolean = false;
}
