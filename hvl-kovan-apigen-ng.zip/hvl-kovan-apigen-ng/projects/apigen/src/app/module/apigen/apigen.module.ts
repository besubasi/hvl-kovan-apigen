import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrimengSharedModule } from '@hvlng/framework-core/shared';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'primeng/api';
import { HvlFormItemModule, HvlFormMessageModule } from '@hvlng/framework-core/form';
import { RxTranslateModule } from '@rxweb/translate';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { ToolbarModule } from 'primeng/toolbar';
import { DialogService } from 'primeng/dynamicdialog';

import { UiSharedModule } from 'ui-shared';

import { ApigenRoutingModule } from '@apigen/module/apigen/apigen-routing.module';

@NgModule({
    declarations: [],
    imports: [
        CommonModule,
        ApigenRoutingModule,
        PrimengSharedModule,
        ToolbarModule,
        TableModule,
        FormsModule,
        SharedModule,
        ReactiveFormsModule,
        HvlFormMessageModule,
        HvlFormItemModule,
        RxTranslateModule,
        DropdownModule,
        UiSharedModule,
    ],
    providers: [DialogService],
})
export class ApigenModule {}
