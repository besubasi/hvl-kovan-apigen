import { JsonObject, JsonProperty } from 'json2typescript';
import { Required } from '@hvlng/framework-bff/core';

@JsonObject('EnumKeyModel')
export class EnumKeyModel {
    @Required()
    @JsonProperty('key', String, true)
    key: string = null;

    @Required()
    @JsonProperty('tr', String, true)
    tr: string = null;

    @Required()
    @JsonProperty('en', String, true)
    en: string = null;

    lineNumber: number = null;
}
