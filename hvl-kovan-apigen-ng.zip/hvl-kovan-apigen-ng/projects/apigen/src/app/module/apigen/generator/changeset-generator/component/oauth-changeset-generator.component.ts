import { Component, OnDestroy, OnInit } from '@angular/core';
import { HvlAbstractOperationalForm } from '@hvlng/framework-core/form';
import { HvlFormGroup } from '@hvlng/framework-bff/core';
import { FormGroup } from '@angular/forms';

import { DropdownOption, UiEnumService, UiToastMessageService, UiTranslateLoaderService } from 'ui-shared';
import { Subscription } from 'rxjs';

import { OauthChangesetModel } from '@apigen/module/apigen/generator/changeset-generator/model/oauth-changeset-model';
import { ChangesetGeneratorService } from '@apigen/module/apigen/generator/changeset-generator/service/changeset-generator-service';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';

@Component({
    selector: 'apigen-oauth-changeset-generate-page',
    templateUrl: './oauth-changeset-generator.component.html',
    styles: [],
})
export class OauthChangesetGeneratorComponent extends HvlAbstractOperationalForm implements OnInit, OnDestroy {
    form: FormGroup;

    // noktalı virgül ile birleştirilmiş hali
    roleCodes: string;

    pageCode: string;
    modelName: string;
    microserviceList: DropdownOption[];
    response: string;

    subscriptions: Subscription[];

    constructor(
        private restService: ChangesetGeneratorService,
        private uiEnumService: UiEnumService,
        private uiToastMessageService: UiToastMessageService,
        private uiTranslateService: UiTranslateLoaderService,
    ) {
        super();
    }

    ngOnInit(): void {
        this.formTitle = 'Oauth Changeset Generator';
        this.modelName = 'oauthChangeSet';
        this.pageCode = 'Code-1454';
        this.subscriptions = [];
        this.response = null;
        this.form = new HvlFormGroup<OauthChangesetModel>(new OauthChangesetModel());
        this.fillEnums();
    }

    ngOnDestroy(): void {
        this.subscriptions?.forEach((x) => x.unsubscribe());
    }

    fillEnums() {
        this.microserviceList = this.uiEnumService.createDropdownList(
            EnumMicroservice,
            this.uiTranslateService.instant('enumMicroservice'),
        );
    }

    onSave() {
        this.form.patchValue({ roleCodeList: this.roleCodes?.length > 0 ? this.roleCodes?.split(';') : null });

        console.log(JSON.stringify(this.form.value));
        this.response = null;
        this.restService.generateOauth(this.form.value).subscribe((response) => {
            this.uiToastMessageService.showSaveSuccess(this.uiTranslateService.instant(this.modelName + '.title'));
            this.response = response?.toString();
        });
    }

    onCancel() {
        this.resetPage();
    }

    private resetPage() {
        this.closeForm();
        this.form.reset();
        this.form.patchValue(new OauthChangesetModel());
        this.response = null;
    }
}
