import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: 'api/generate',
                loadChildren: () =>
                    import('@apigen/module/apigen/generator/api-generator/api-generator.module').then(
                        (m) => m.ApiGeneratorModule,
                    ),
            },
            {
                path: 'enum/generate',
                loadChildren: () =>
                    import('@apigen/module/apigen/generator/enum-generator/enum-generator.module').then(
                        (m) => m.EnumGeneratorModule,
                    ),
            },
            {
                path: 'changeset/generate',
                loadChildren: () =>
                    import('@apigen/module/apigen/generator/changeset-generator/changeset-generator.module').then(
                        (m) => m.ChangesetGeneratorModule,
                    ),
            },
            {
                path: 'frontend/copy',
                loadChildren: () =>
                    import('@apigen/module/apigen/generator/frontend-copy/frontend-copy.module').then(
                        (m) => m.FrontendCopyModule,
                    ),
            },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ApigenRoutingModule {}
