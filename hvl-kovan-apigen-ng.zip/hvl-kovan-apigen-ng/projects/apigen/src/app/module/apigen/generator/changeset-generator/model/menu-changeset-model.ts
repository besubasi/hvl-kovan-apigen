import { JsonObject, JsonProperty } from 'json2typescript';
import { EmptyControl, Required } from '@hvlng/framework-bff/core';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';

@JsonObject('MenuChangesetModel')
export class MenuChangesetModel {
    @Required()
    @JsonProperty('microservice', String, true)
    microservice: EnumMicroservice = null;

    @Required()
    @JsonProperty('label', String, true)
    label: string = null;

    @EmptyControl()
    @JsonProperty('path', String, true)
    path: string = null;

    @EmptyControl()
    @JsonProperty('parentUuid', String, true)
    parentUuid: string = null;

    @Required()
    @JsonProperty('order', Number, true)
    order: number = null;

    @EmptyControl()
    @JsonProperty('authorityCode', String, true)
    authorityCode: string = null;
}
