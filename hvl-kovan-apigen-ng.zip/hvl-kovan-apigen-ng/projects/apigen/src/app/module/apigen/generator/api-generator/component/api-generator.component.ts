import { Component, OnDestroy, OnInit } from '@angular/core';
import { HvlAbstractOperationalForm, HvlEnumGridColumn } from '@hvlng/framework-core/form';
import { HvlFormGroup } from '@hvlng/framework-bff/core';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';

import { DropdownOption, UiEnumService, UiToastMessageService, UiTranslateLoaderService } from 'ui-shared';

import { ApiGeneratorService } from '@apigen/module/apigen/generator/api-generator/service/api-generator-service';
import { ApiGeneratorModel } from '@apigen/module/apigen/generator/api-generator/model/api-generator-model';
import { FormMode } from '@apigen/module/apigen/common/form-mode';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';
import { PropertyModel } from '@apigen/module/apigen/generator/api-generator/model/property-model';
import { EnumModule } from '@apigen/module/apigen/common/enum-module';
import { EnumExtendedType } from '@apigen/module/apigen/generator/api-generator/model/enum-extended-type';

@Component({
    selector: 'apigen-api-generate-page',
    templateUrl: './api-generator.component.html',
    styles: [],
})
export class ApiGeneratorComponent extends HvlAbstractOperationalForm implements OnInit, OnDestroy {
    form: FormGroup;
    propertyForm: FormGroup;
    model: ApiGeneratorModel;
    propertyModel: PropertyModel;
    pageCode: string;
    modelName: string;

    selectedItem: PropertyModel;
    microserviceList: DropdownOption[];
    extendsList: DropdownOption[];
    moduleList: DropdownOption[];
    allModuleList: DropdownOption[];
    subscriptions: Subscription[];

    constructor(
        private restService: ApiGeneratorService,
        private uiToastMessageService: UiToastMessageService,
        private uiEnumService: UiEnumService,
        private uiTranslateService: UiTranslateLoaderService,
    ) {
        super();
    }

    ngOnInit(): void {
        this.formTitle = 'Api Oluştur';
        this.modelName = 'apiGenerate';
        this.pageCode = 'Code-1071';
        this.subscriptions = [];
        this.model = new ApiGeneratorModel();
        this.propertyModel = new PropertyModel();
        this.form = new HvlFormGroup<ApiGeneratorModel>(new ApiGeneratorModel());
        this.propertyForm = new HvlFormGroup<PropertyModel>(new PropertyModel());
        this.fillEnums();
    }

    ngOnDestroy(): void {
        this.subscriptions?.forEach((x) => x.unsubscribe());
    }

    fillEnums() {
        this.microserviceList = this.uiEnumService.createDropdownList(
            EnumMicroservice,
            this.uiTranslateService.instant('enumMicroservice'),
        );
        this.allModuleList = this.uiEnumService.createDropdownList(
            EnumModule,
            this.uiTranslateService.instant('enumModule'),
        );
        this.extendsList = this.uiEnumService.createDropdownList(
            EnumExtendedType,
            this.uiTranslateService.instant('enumExtendsType'),
        );
    }

    onAdd() {
        this.selectedItem = null;
        this.setButtonItemUnSelectedMode();
        this.openForm(FormMode.ADD, 'Property Ekle', HvlEnumGridColumn.COL3);
        this.initializeData();
    }

    onCopy() {
        this.openForm(FormMode.COPY, 'Property Kopyala', HvlEnumGridColumn.COL3);
        this.initializeData();
    }

    onEdit() {
        this.openForm(FormMode.EDIT, 'Property Düzenle', HvlEnumGridColumn.COL3);
        this.initializeData();
    }

    onDelete() {
        this.form?.value?.propertyList?.findIndex((x) => x.name == this.selectedItem?.name);
    }

    initializeData() {
        if (this.formMode == FormMode.ADD) {
            this.propertyModel = new PropertyModel();
            this.propertyForm.patchValue(this.propertyModel);
        } else if (this.formMode == FormMode.EDIT) {
            this.propertyForm.patchValue(Object.assign({}, this.selectedItem));
        } else if (this.formMode == FormMode.COPY) {
            this.propertyModel = Object.assign({}, this.selectedItem);
            this.propertyForm.patchValue(this.propertyModel);
        }
    }

    onChangeMicroservice() {
        let microservice = this.form.value.microservice;
        if (!microservice) {
            this.moduleList = [];
            this.form.patchValue({ module: null });
            return;
        }
        let filteredModuleList: EnumModule[] = [];
        if (EnumMicroservice.LOGISTIC_GENERAL === microservice)
            filteredModuleList = [
                EnumModule.CONDITION,
                EnumModule.GENERAL,
                EnumModule.GENERAL_ADDRESS,
                EnumModule.INTEGRATIONS,
                EnumModule.ORGANIZATION,
                EnumModule.PARAMETERS,
            ];
        else if (EnumMicroservice.MATERIAL_MANAGEMENT === microservice)
            filteredModuleList = [
                EnumModule.MATERIAL_IDENTIFICATION,
                EnumModule.PURCHASING,
                EnumModule.STOCK,
                EnumModule.WAREHOUSE,
            ];
        else if (EnumMicroservice.MAINTENANCE_MANAGEMENT === microservice)
            filteredModuleList = [
                EnumModule.CONFIGURATION_MANAGEMENT,
                EnumModule.ENGINEERING,
                EnumModule.MAINTENANCE_ASSETS_MANAGEMENT,
                EnumModule.MAINTENANCE_REPAIR_APPLICATION,
                EnumModule.PREVENTIVE_MAINTENANCE,
            ];
        else if (EnumMicroservice.PRODUCTION === microservice)
            filteredModuleList = [EnumModule.PRODUCTION_CUSTOMISATION, EnumModule.PRODUCTION_APPLICATION];
        else if (EnumMicroservice.QUALITY === microservice)
            filteredModuleList = [EnumModule.QUALITY_CUSTOMISATION, EnumModule.QUALITY_APPLICATION];
        else if (EnumMicroservice.SALES === microservice)
            filteredModuleList = [EnumModule.SALES_CUSTOMISATION, EnumModule.SALES_APPLICATION];
        else if (EnumMicroservice.PROGRESS === microservice)
            filteredModuleList = [EnumModule.PROGRESS_CUSTOMISATION, EnumModule.PROGRESS_APPLICATION];

        this.moduleList = this.allModuleList?.filter((x) => filteredModuleList.includes(EnumModule[x.value]));
    }

    onChangeExtendsType($event) {
        let extendsType = $event.value;
        let extendedName: string;
        if (EnumExtendedType.KOVAN_ACTIVABLE == extendsType) extendedName = 'KovanActivable';
        else if (EnumExtendedType.HVL_HARD_DELETE == extendsType) extendedName = 'HvlHardDelete';
        else if (EnumExtendedType.HVL_SOFT_DELETE == extendsType) extendedName = 'HvlSoftDelete';

        this.form.patchValue({ extendedName: extendedName });
    }

    onOk() {
        let value: PropertyModel = this.propertyForm.value;
        if (FormMode.EDIT == this.formMode) {
            let index = this.form?.value?.propertyList?.findIndex((x) => x.name == this.selectedItem.name);
            this.form.value.propertyList[index] = value;
        } else {
            this.form.value.propertyList.push(value);
        }
        this.onClose();
    }

    onSave() {
        console.log(JSON.stringify(this.form.value));
        this.restService.generate(this.form.value).subscribe(() => {
            this.uiToastMessageService.showSaveSuccess(this.uiTranslateService.instant(this.modelName + '.title'));
        });
    }

    onClose() {
        this.closeForm();
        this.onRowUnSelect();
        this.propertyForm.reset();
    }

    onCancel() {
        this.resetPage();
    }

    private resetPage() {
        this.closeForm();
        this.form.reset();
        this.propertyForm.reset();
        this.form.patchValue(new ApiGeneratorModel());
        this.onRowUnSelect();
    }

    onRowSelect() {
        this.setButtonItemSelectedMode();
    }

    onRowUnSelect() {
        this.setButtonItemUnSelectedMode();
    }
}
