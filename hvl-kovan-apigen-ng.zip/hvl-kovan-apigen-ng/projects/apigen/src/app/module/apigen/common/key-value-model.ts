import { Any, JsonObject, JsonProperty } from 'json2typescript';
import { Required } from '@hvlng/framework-bff/core';

@JsonObject('KeyValueModel')
export class KeyValueModel {
    @Required()
    @JsonProperty('key', String, true)
    key: string = null;

    @Required()
    @JsonProperty('value', Any, true)
    value: any = null;
}
