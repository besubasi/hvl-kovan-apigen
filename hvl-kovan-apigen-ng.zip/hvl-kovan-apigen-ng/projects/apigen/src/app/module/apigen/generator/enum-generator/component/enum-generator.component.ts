import { Component, OnDestroy, OnInit } from '@angular/core';
import { HvlAbstractOperationalForm, HvlEnumGridColumn } from '@hvlng/framework-core/form';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';
import { HvlFormGroup } from '@hvlng/framework-bff/core';

import { DropdownOption, UiEnumService, UiToastMessageService, UiTranslateLoaderService } from 'ui-shared';

import { EnumGeneratorService } from '@apigen/module/apigen/generator/enum-generator/service/enum-generator-service';
import { EnumGeneratorModel } from '@apigen/module/apigen/generator/enum-generator/model/enum-generator-model';
import { EnumKeyModel } from '@apigen/module/apigen/generator/enum-generator/model/enum-key-model';
import { FormMode } from '@apigen/module/apigen/common/form-mode';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';

@Component({
    selector: 'apigen-enum-generate-page',
    templateUrl: './enum-generator.component.html',
    styles: [],
})
export class EnumGeneratorComponent extends HvlAbstractOperationalForm implements OnInit, OnDestroy {
    form: FormGroup;
    keyForm: FormGroup;
    model: EnumGeneratorModel;
    keyModel: EnumKeyModel;
    pageCode: string;
    modelName: string;

    selectedItem: EnumKeyModel;
    microservice: DropdownOption[];
    subscriptions: Subscription[];

    constructor(
        private restService: EnumGeneratorService,
        private uiToastMessageService: UiToastMessageService,
        private uiEnumService: UiEnumService,
        private uiTranslateService: UiTranslateLoaderService,
    ) {
        super();
    }

    ngOnInit(): void {
        this.formTitle = 'Enum Oluştur';
        this.modelName = 'enumGenerate';
        this.pageCode = 'Code-1453';
        this.subscriptions = [];
        this.model = new EnumGeneratorModel();
        this.keyModel = new EnumKeyModel();
        this.form = new HvlFormGroup<EnumGeneratorModel>(this.model);
        this.keyForm = new HvlFormGroup<EnumKeyModel>(new EnumKeyModel());
        this.fillEnums();
    }

    ngOnDestroy(): void {
        this.subscriptions?.forEach((x) => x.unsubscribe());
    }

    fillEnums() {
        this.microservice = this.uiEnumService.createDropdownList(
            EnumMicroservice,
            this.uiTranslateService.instant('enumMicroservice'),
        );
    }

    onAdd() {
        this.selectedItem = null;
        this.setButtonItemUnSelectedMode();
        this.openForm(FormMode.ADD, 'Key Ekle', HvlEnumGridColumn.COL3);
        this.initializeData();
    }

    onCopy() {
        this.openForm(FormMode.COPY, 'Key Kopyala', HvlEnumGridColumn.COL3);
        this.initializeData();
    }

    onEdit() {
        this.openForm(FormMode.EDIT, 'Key Düzenle', HvlEnumGridColumn.COL3);
        this.initializeData();
    }

    onDelete() {
        this.form?.value?.keyList?.findIndex((x) => x.lineNumber == this.selectedItem?.lineNumber);
    }

    initializeData() {
        if (this.formMode == FormMode.ADD) {
            this.keyModel = new EnumKeyModel();
            this.keyModel.lineNumber = this.form?.value?.keyList?.length + 1;
            this.keyForm.patchValue(this.keyModel);
        } else if (this.formMode == FormMode.EDIT) {
            this.keyForm.patchValue(this.selectedItem);
        } else if (this.formMode == FormMode.COPY) {
            this.keyModel = Object.assign({}, this.selectedItem);
            this.keyModel.lineNumber = this.form?.value?.keyList?.length + 1;
            this.keyForm.patchValue(this.keyModel);
        }
    }

    onOk() {
        let value: EnumKeyModel = this.keyForm.value;
        if (FormMode.EDIT == this.formMode) {
            let index = this.form?.value?.keyList?.findIndex((x) => x.key == this.selectedItem.key);
            this.form.value.keyList[index] = value;
        } else {
            this.form.value.keyList.push(value);
        }
        this.onClose();
    }

    onSave() {
        this.restService.generate(this.form.value).subscribe(() => {
            this.uiToastMessageService.showSaveSuccess(this.uiTranslateService.instant(this.modelName + '.title'));
            //this.resetPage();
        });
    }

    onClose() {
        this.closeForm();
        this.keyForm.reset();
    }

    onCancel() {
        this.resetPage();
    }

    private resetPage() {
        this.closeForm();
        this.form.reset();
        this.keyForm.reset();
        this.form.patchValue(new EnumGeneratorModel());
        this.onRowUnSelect();
    }

    onRowSelect() {
        this.setButtonItemSelectedMode();
    }

    onRowUnSelect() {
        this.setButtonItemUnSelectedMode();
    }
}
