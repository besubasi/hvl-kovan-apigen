import { Component, OnDestroy, OnInit } from '@angular/core';
import { HvlAbstractOperationalForm } from '@hvlng/framework-core/form';
import { HvlFormGroup, HvlValidNotationService } from '@hvlng/framework-bff/core';
import { FormGroup } from '@angular/forms';
import { DialogService } from 'primeng/dynamicdialog';

import {
    DropdownOption,
    UiConfirmationDialogService,
    UiEnumService,
    UiToastMessageService,
    UiTranslateLoaderService,
} from 'ui-shared';

import { EnumGeneratorService } from '@apigen/module/apigen/generator/enum-generator/service/enum-generator-service';
import { EnumGeneratorModel } from '@apigen/module/apigen/generator/enum-generator/model/enum-generator-model';
import { EnumKeyModel } from '@apigen/module/apigen/generator/enum-generator/model/enum-key-model';
import { FormMode } from '@apigen/module/apigen/common/form-mode';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';
import { Subscription } from 'rxjs';

@Component({
    selector: 'apigen-enum-generate-page',
    templateUrl: './enum-generator2.component.html',
    styles: [],
})
export class EnumGenerator2Component extends HvlAbstractOperationalForm implements OnInit, OnDestroy {
    form: FormGroup;
    keyForm: FormGroup;
    model: EnumGeneratorModel;
    keyModel: EnumKeyModel;
    pageCode: string;
    modelName: string;

    selectedItem: EnumKeyModel;
    microservice: DropdownOption[];
    subscriptions: Subscription[];

    constructor(
        private restService: EnumGeneratorService,
        private validNotationService: HvlValidNotationService,
        private dialogService: DialogService,
        private confirmationDialogService: UiConfirmationDialogService,
        private uiToastMessageService: UiToastMessageService,
        private uiEnumService: UiEnumService,
        protected uiTranslateService: UiTranslateLoaderService,
    ) {
        super();
    }

    ngOnInit(): void {
        this.formTitle = 'Enum Oluştur';
        this.modelName = 'enumGenerate';
        this.pageCode = 'Code-1453';
        this.model = new EnumGeneratorModel();
        this.keyModel = new EnumKeyModel();
        this.form = new HvlFormGroup<EnumGeneratorModel>(this.model);
        this.keyForm = new HvlFormGroup<EnumKeyModel>(new EnumKeyModel());
        this.fillEnums();
    }

    ngOnDestroy(): void {
        this.subscriptions?.forEach((x) => x.unsubscribe());
    }

    fillEnums() {
        this.microservice = this.uiEnumService.createDropdownList(
            EnumMicroservice,
            this.uiTranslateService.instant('enumMicroservice'),
        );
    }

    onRemove() {
        this.confirmationDialogService.showDeleteConfirmDialog(() => {
            this.form.value.keyList = this.form.value.keyList.filter((e) => this.selectedItem.key != e.key);
            this.onRowUnSelect();
        });
    }

    onOk() {
        if (FormMode.EDIT == this.formMode) {
            let index = this.form?.value?.keyList?.findIndex((x) => x.key == this.selectedItem.key);
            this.form.value.keyList[index] = this.keyForm.value;
        } else {
            this.form.value.keyList.push(this.keyForm.value);
        }
        this.onRowUnSelect();
    }

    onSave() {
        this.restService.generate(this.form.value).subscribe(() => {
            this.uiToastMessageService.showSaveSuccess(this.uiTranslateService.instant(this.modelName + '.title'));
            this.resetPage();
        });
    }

    private resetPage() {
        this.resetForm();
        this.closeForm();
    }

    private resetForm() {
        this.form.reset();
        this.keyForm.reset();
    }

    onRowSelect() {
        this.formMode = FormMode.EDIT;
        this.keyForm.patchValue(this.selectedItem);
    }

    onRowUnSelect() {
        this.selectedItem = null;
        this.formMode = FormMode.ADD;
        this.keyForm.reset();
    }

    get FormMode() {
        return FormMode;
    }
}
