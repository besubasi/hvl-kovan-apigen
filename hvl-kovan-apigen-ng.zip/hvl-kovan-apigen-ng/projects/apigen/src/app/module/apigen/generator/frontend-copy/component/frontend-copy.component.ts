import { Component, OnDestroy, OnInit } from '@angular/core';
import { HvlAbstractOperationalForm, HvlEnumGridColumn } from '@hvlng/framework-core/form';
import { HvlFormGroup } from '@hvlng/framework-bff/core';
import { FormGroup } from '@angular/forms';
import { Subscription } from 'rxjs';

import { UiEnumService, UiToastMessageService, UiTranslateLoaderService } from 'ui-shared';

import { FrontendCopyService } from '@apigen/module/apigen/generator/frontend-copy/service/frontend-copy-service';
import { FrontendCopyModel } from '@apigen/module/apigen/generator/frontend-copy/model/frontend-copy-model';
import { FormMode } from '@apigen/module/apigen/common/form-mode';
import { KeyValueModel } from '@apigen/module/apigen/common/key-value-model';

@Component({
    selector: 'apigen-frontend-copy-page',
    templateUrl: './frontend-copy.component.html',
    styles: [],
})
export class FrontendCopyComponent extends HvlAbstractOperationalForm implements OnInit, OnDestroy {
    form: FormGroup;
    keyValueForm: FormGroup;
    model: FrontendCopyModel;
    keyValueModel: KeyValueModel;
    pageCode: string;
    modelName: string;

    selectedItem: KeyValueModel;
    subscriptions: Subscription[];

    keyValueList: KeyValueModel[];

    constructor(
        private restService: FrontendCopyService,
        private uiToastMessageService: UiToastMessageService,
        private uiEnumService: UiEnumService,
        private uiTranslateService: UiTranslateLoaderService,
    ) {
        super();
    }

    ngOnInit(): void {
        this.formTitle = 'Frontent Copy Bilgileri';
        this.modelName = 'frontend';
        this.pageCode = 'Code-1920';
        this.subscriptions = [];
        this.keyValueList = [];
        this.model = new FrontendCopyModel();
        this.keyValueModel = new KeyValueModel();
        this.form = new HvlFormGroup<FrontendCopyModel>(new FrontendCopyModel());
        this.keyValueForm = new HvlFormGroup<KeyValueModel>(new KeyValueModel());
    }

    ngOnDestroy(): void {
        this.subscriptions?.forEach((x) => x.unsubscribe());
    }

    onAdd() {
        this.selectedItem = null;
        this.setButtonItemUnSelectedMode();
        this.openForm(FormMode.ADD, 'Key Value Ekle', HvlEnumGridColumn.COL3);
        this.initializeData();
    }

    onCopy() {
        this.openForm(FormMode.COPY, 'Key Value Kopyala', HvlEnumGridColumn.COL3);
        this.initializeData();
    }

    onEdit() {
        this.openForm(FormMode.EDIT, 'Key Value Düzenle', HvlEnumGridColumn.COL3);
        this.initializeData();
    }

    onDelete() {
        this.form?.value?.keyValueList?.findIndex((x) => x.key == this.selectedItem?.key);
    }

    initializeData() {
        if (this.formMode == FormMode.ADD) {
            this.keyValueModel = new KeyValueModel();
            this.keyValueForm.patchValue(this.keyValueModel);
        } else if (this.formMode == FormMode.EDIT) {
            this.keyValueForm.patchValue(Object.assign({}, this.selectedItem));
        } else if (this.formMode == FormMode.COPY) {
            this.keyValueModel = Object.assign({}, this.selectedItem);
            this.keyValueForm.patchValue(this.keyValueModel);
        }
    }

    onOk() {
        let value: KeyValueModel = this.keyValueForm.value;
        if (FormMode.EDIT == this.formMode) {
            let index = this.keyValueList?.findIndex((x) => x.key == this.selectedItem.key);
            this.keyValueList[index] = value;
        } else {
            this.keyValueList.push(value);
        }
        this.onClose();
    }

    onSave() {
        this.keyValueList?.forEach((keyValue) => this.form.value.keyValueMap.set(keyValue.key, keyValue.value));
        console.log(JSON.stringify(this.form.value));
        this.restService.copy(this.form.value).subscribe(() => {
            this.uiToastMessageService.showSaveSuccess(this.uiTranslateService.instant(this.modelName + '.title'));
            //this.resetPage();
        });
    }

    onClose() {
        this.closeForm();
        this.onRowUnSelect();
        this.keyValueForm.reset();
    }

    onCancel() {
        this.resetPage();
        /*
        this.confirmationDialogService.showBasicConfirmDialog(
            this.uiTranslateService.instant('confirm.warningConfirmHeader'),
            this.uiTranslateService.instant('confirm.warningClearFormsMessage'),
            () => {
                this.resetPage();
            },
        );
*/
    }

    private resetPage() {
        this.closeForm();
        this.form.reset();
        this.keyValueForm.reset();
        this.form.patchValue(new FrontendCopyModel());
        this.onRowUnSelect();
    }

    onRowSelect() {
        this.setButtonItemSelectedMode();
    }

    onRowUnSelect() {
        this.setButtonItemUnSelectedMode();
    }
}
