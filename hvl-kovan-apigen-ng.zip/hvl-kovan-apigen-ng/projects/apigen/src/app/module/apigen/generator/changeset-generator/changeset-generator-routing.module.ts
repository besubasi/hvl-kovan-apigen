import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { MenuChangesetGeneratorComponent } from '@apigen/module/apigen/generator/changeset-generator/component/menu-changeset-generator.component';
import { OauthChangesetGeneratorComponent } from '@apigen/module/apigen/generator/changeset-generator/component/oauth-changeset-generator.component';

const routes: Routes = [
    { path: 'menu', component: MenuChangesetGeneratorComponent },
    { path: 'oauth', component: OauthChangesetGeneratorComponent },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ChangesetGeneratorRoutingModule {}
