import { JsonObject, JsonProperty } from 'json2typescript';
import { EmptyControl, Required } from '@hvlng/framework-bff/core';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';

@JsonObject('OauthChangesetModel')
export class OauthChangesetModel {
    @Required()
    @JsonProperty('microservice', String, true)
    microservice: EnumMicroservice = null;

    @Required()
    @JsonProperty('code', String, true)
    code: string = null;

    @Required()
    @JsonProperty('label', String, true)
    label: string = null;

    @EmptyControl()
    @JsonProperty('roleCodeList', [String], true)
    roleCodeList: string[] = [];
}
