import { JsonObject, JsonProperty } from 'json2typescript';
import { EmptyControl, Required } from '@hvlng/framework-bff/core';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';

import { PropertyModel } from '@apigen/module/apigen/generator/api-generator/model/property-model';
import { EnumModule } from '@apigen/module/apigen/common/enum-module';

@JsonObject('ApiGeneratorModel')
export class ApiGeneratorModel {
    @Required()
    @JsonProperty('microservice', String, true)
    microservice: EnumMicroservice = null;

    @Required()
    @JsonProperty('module', String, true)
    module: EnumModule = null;

    @Required()
    @JsonProperty('apiName', String, true)
    apiName: string = null;

    @Required()
    @JsonProperty('apiPackage', String, true)
    apiPackage: string = null;

    @Required()
    @JsonProperty('tableName', String, true)
    tableName: string = null;

    @Required()
    @JsonProperty('extendedName', String, true)
    extendedName: string = null;

    @EmptyControl()
    @JsonProperty('hasDefEntity', Boolean, true)
    hasDefEntity: boolean = false;

    @EmptyControl()
    @JsonProperty('hasBusinessRule', Boolean, true)
    hasBusinessRule: boolean = true;

    @EmptyControl()
    @JsonProperty('isView', Boolean, true)
    isView: boolean = false;

    @EmptyControl()
    @JsonProperty('createConstant', Boolean, true)
    createConstant: boolean = true;

    @EmptyControl()
    @JsonProperty('createEntity', Boolean, true)
    createEntity: boolean = true;

    @EmptyControl()
    @JsonProperty('createEntityQuery', Boolean, true)
    createEntityQuery: boolean = true;

    @EmptyControl()
    @JsonProperty('createDefEntity', Boolean, true)
    createDefEntity: boolean = true;

    @EmptyControl()
    @JsonProperty('createDefEntityQuery', Boolean, true)
    createDefEntityQuery: boolean = true;

    @EmptyControl()
    @JsonProperty('createModel', Boolean, true)
    createModel: boolean = true;

    @EmptyControl()
    @JsonProperty('createQueryModel', Boolean, true)
    createQueryModel: boolean = true;

    @EmptyControl()
    @JsonProperty('createQueryGenerator', Boolean, true)
    createQueryGenerator: boolean = true;

    @EmptyControl()
    @JsonProperty('createConverter', Boolean, true)
    createConverter: boolean = true;

    @EmptyControl()
    @JsonProperty('createConverterImpl', Boolean, true)
    createConverterImpl: boolean = true;

    @EmptyControl()
    @JsonProperty('createBasicConverter', Boolean, true)
    createBasicConverter: boolean = true;

    @EmptyControl()
    @JsonProperty('createBasicConverterImpl', Boolean, true)
    createBasicConverterImpl: boolean = true;

    @EmptyControl()
    @JsonProperty('createRepository', Boolean, true)
    createRepository: boolean = true;

    @EmptyControl()
    @JsonProperty('createRules', Boolean, true)
    createRules: boolean = true;

    @EmptyControl()
    @JsonProperty('createRuleService', Boolean, true)
    createRuleService: boolean = true;

    @EmptyControl()
    @JsonProperty('createService', Boolean, true)
    createService: boolean = true;

    @EmptyControl()
    @JsonProperty('createServiceImpl', Boolean, true)
    createServiceImpl: boolean = true;

    @EmptyControl()
    @JsonProperty('createPrivateRestService', Boolean, true)
    createPrivateRestService: boolean = true;

    @EmptyControl()
    @JsonProperty('createPublicRestService', Boolean, true)
    createPublicRestService: boolean = true;

    @EmptyControl()
    @JsonProperty('createRestController', Boolean, true)
    createRestController: boolean = true;

    @EmptyControl()
    @JsonProperty('updateYml', Boolean, true)
    updateYml: boolean = true;

    @EmptyControl()
    @JsonProperty('propertyList', [PropertyModel], true)
    propertyList: PropertyModel[] = [];
}
