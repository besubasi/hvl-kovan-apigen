import { Component, OnDestroy, OnInit } from '@angular/core';
import { HvlAbstractOperationalForm } from '@hvlng/framework-core/form';
import { HvlFormGroup } from '@hvlng/framework-bff/core';
import { FormGroup } from '@angular/forms';

import { DropdownOption, UiEnumService, UiToastMessageService, UiTranslateLoaderService } from 'ui-shared';
import { Subscription } from 'rxjs';

import { MenuChangesetModel } from '@apigen/module/apigen/generator/changeset-generator/model/menu-changeset-model';
import { ChangesetGeneratorService } from '@apigen/module/apigen/generator/changeset-generator/service/changeset-generator-service';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';

@Component({
    selector: 'apigen-menu-changeset-generate-page',
    templateUrl: './menu-changeset-generator.component.html',
    styles: [],
})
export class MenuChangesetGeneratorComponent extends HvlAbstractOperationalForm implements OnInit, OnDestroy {
    form: FormGroup;

    pageCode: string;
    modelName: string;
    microserviceList: DropdownOption[];
    response: string;

    subscriptions: Subscription[];

    constructor(
        private restService: ChangesetGeneratorService,
        private uiEnumService: UiEnumService,
        private uiToastMessageService: UiToastMessageService,
        private uiTranslateService: UiTranslateLoaderService,
    ) {
        super();
    }

    ngOnInit(): void {
        this.formTitle = 'Menu Changeset Oluştur';
        this.modelName = 'menuChangeSet';
        this.pageCode = 'Code-1454';
        this.subscriptions = [];
        this.response = null;
        this.form = new HvlFormGroup<MenuChangesetModel>(new MenuChangesetModel());
        this.fillEnums();
    }

    ngOnDestroy(): void {
        this.subscriptions?.forEach((x) => x.unsubscribe());
    }

    fillEnums() {
        this.microserviceList = this.uiEnumService.createDropdownList(
            EnumMicroservice,
            this.uiTranslateService.instant('enumMicroservice'),
        );
    }

    onSave() {
        this.response = null;
        console.log(JSON.stringify(this.form.value));
        this.restService.generateMenu(this.form.value).subscribe((response) => {
            this.uiToastMessageService.showSaveSuccess(this.uiTranslateService.instant('Menu Changeset'));
            this.response = response?.toString();
            //this.resetPage();
        });
    }

    onCancel() {
        this.resetPage();
    }

    private resetPage() {
        this.closeForm();
        this.form.reset();
        this.form.patchValue(new MenuChangesetModel());
        this.response = null;
    }
}
