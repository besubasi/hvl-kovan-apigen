import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FrontendCopyComponent } from '@apigen/module/apigen/generator/frontend-copy/component/frontend-copy.component';

const routes: Routes = [{ path: '', component: FrontendCopyComponent }];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class FrontendCopyRoutingModule {}
