import { JsonObject, JsonProperty } from 'json2typescript';
import { EmptyControl, Required } from '@hvlng/framework-bff/core';

import { EnumKeyModel } from '@apigen/module/apigen/generator/enum-generator/model/enum-key-model';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';

@JsonObject('EnumGeneratorModel')
export class EnumGeneratorModel {
    @Required()
    @JsonProperty('microservice', String, true)
    microservice: EnumMicroservice = null;

    @Required()
    @JsonProperty('name', String, true)
    name: string = null;

    @Required()
    @JsonProperty('commonSubPackage', String, true)
    commonSubPackage: string = null;

    @Required()
    @JsonProperty('sharedPackage', String, true)
    sharedPackage: string = null;

    @EmptyControl()
    @JsonProperty('keyList', [EnumKeyModel], true)
    keyList: EnumKeyModel[] = [];
}
