import { HvlFormConstants } from '@hvlng/framework-core/form';

export class FormMode extends HvlFormConstants {
    static VIEW = 'view';
    static INFO = 'info';
}
