import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { EnumGeneratorComponent } from '@apigen/module/apigen/generator/enum-generator/component/enum-generator.component';
import { EnumGenerator2Component } from '@apigen/module/apigen/generator/enum-generator/component2/enum-generator2.component';

const routes: Routes = [
    { path: '', component: EnumGeneratorComponent },
    { path: 'iki', component: EnumGenerator2Component },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class EnumGeneratorRoutingModule {}
