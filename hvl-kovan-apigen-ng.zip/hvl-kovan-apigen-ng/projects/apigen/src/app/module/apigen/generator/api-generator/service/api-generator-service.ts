import { HvlResponse } from '@hvlng/framework-bff/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { finalize, map } from 'rxjs/operators';

import { PreloaderService } from 'ui-shared';

import { ApiGeneratorModel } from '@apigen/module/apigen/generator/api-generator/model/api-generator-model';

@Injectable({
    providedIn: 'root',
})
export class ApiGeneratorService {
    endpoint: string;

    constructor(private httpClient: HttpClient, private uiPreloaderService: PreloaderService) {
        this.endpoint = 'http://apigen.hvlnet.net:8080/apigen/api';
    }

    public generate(model: ApiGeneratorModel): Observable<Boolean> {
        this.uiPreloaderService.show();

        return this.httpClient.post<HvlResponse<Boolean>>(this.endpoint + '/generate', model).pipe(
            map((data) => Boolean(data)),
            finalize(() => this.uiPreloaderService.hide()),
        );
    }
}
