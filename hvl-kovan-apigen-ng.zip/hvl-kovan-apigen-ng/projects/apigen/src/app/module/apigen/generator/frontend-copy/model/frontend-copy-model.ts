import { JsonObject, JsonProperty } from 'json2typescript';
import { EmptyControl, Required } from '@hvlng/framework-bff/core';
import { EnumMicroservice } from '@apigen/module/apigen/common/enum-microservice';

import { PropertyModel } from '@apigen/module/apigen/generator/api-generator/model/property-model';
import { EnumModule } from '@apigen/module/apigen/common/enum-module';
import { HvlMapConverter } from '@hvlng/framework-bff/util';
import { KeyValueModel } from '@apigen/module/apigen/common/key-value-model';

@JsonObject('FrontendCopyModel')
export class FrontendCopyModel {
    @Required()
    @JsonProperty('sourcePath', String, true)
    sourcePath: string = null;

    @Required()
    @JsonProperty('targetPath', String, true)
    targetPath: string = null;

    @EmptyControl()
    @JsonProperty('keyValueMap', HvlMapConverter, true)
    keyValueMap: Map<string, string> = new Map<string, string>();
}
