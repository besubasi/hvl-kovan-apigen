import { HvlResponse } from '@hvlng/framework-bff/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { finalize, map } from 'rxjs/operators';

import { PreloaderService } from 'ui-shared';

import { EnumGeneratorModel } from '@apigen/module/apigen/generator/enum-generator/model/enum-generator-model';

@Injectable({
    providedIn: 'root',
})
export class EnumGeneratorService {
    endpoint: string;

    constructor(private httpClient: HttpClient, private uiPreloaderService: PreloaderService) {
        this.endpoint = 'http://apigen.hvlnet.net:8080/apigen/enum';
    }

    public generate(model: EnumGeneratorModel): Observable<Boolean> {
        this.uiPreloaderService.show();

        return this.httpClient.post<HvlResponse<Boolean>>(this.endpoint + '/generate', model).pipe(
            map((data) => Boolean(data.body)),
            finalize(() => this.uiPreloaderService.hide()),
        );
    }
}
