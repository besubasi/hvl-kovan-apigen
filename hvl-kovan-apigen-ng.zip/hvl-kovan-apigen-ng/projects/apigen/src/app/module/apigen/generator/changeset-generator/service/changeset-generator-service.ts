import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { finalize, map } from 'rxjs/operators';
import { HvlResponse } from '@hvlng/framework-bff/core';

import { PreloaderService } from 'ui-shared';

import { MenuChangesetModel } from '@apigen/module/apigen/generator/changeset-generator/model/menu-changeset-model';
import { OauthChangesetModel } from '@apigen/module/apigen/generator/changeset-generator/model/oauth-changeset-model';

@Injectable({
    providedIn: 'root',
})
export class ChangesetGeneratorService {
    endpoint: string;

    constructor(private httpClient: HttpClient, private uiPreloaderService: PreloaderService) {
        this.endpoint = 'http://apigen.hvlnet.net:8080/apigen/changeset/generate';
    }

    public generateMenu(model: MenuChangesetModel): Observable<String> {
        this.uiPreloaderService.show();

        return this.httpClient.post<HvlResponse<String>>(this.endpoint + '/menu', model).pipe(
            map((data) => data.body),
            finalize(() => this.uiPreloaderService.hide()),
        );
    }

    public generateOauth(model: OauthChangesetModel): Observable<String> {
        this.uiPreloaderService.show();

        return this.httpClient.post<HvlResponse<String>>(this.endpoint + '/oauth', model).pipe(
            map((data) => data.body),
            finalize(() => this.uiPreloaderService.hide()),
        );
    }
}
