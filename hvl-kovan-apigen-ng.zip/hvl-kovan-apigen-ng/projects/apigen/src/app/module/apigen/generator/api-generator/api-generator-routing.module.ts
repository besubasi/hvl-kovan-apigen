import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ApiGeneratorComponent } from '@apigen/module/apigen/generator/api-generator/component/api-generator.component';

const routes: Routes = [{ path: '', component: ApiGeneratorComponent }];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],
})
export class ApiGeneratorRoutingModule {}
