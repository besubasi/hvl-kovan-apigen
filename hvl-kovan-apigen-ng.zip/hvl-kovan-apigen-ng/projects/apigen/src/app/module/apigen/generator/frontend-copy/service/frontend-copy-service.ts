import { HvlResponse } from '@hvlng/framework-bff/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { finalize, map } from 'rxjs/operators';
import { JsonConvert } from 'json2typescript';

import { PreloaderService } from 'ui-shared';

import { FrontendCopyModel as T } from '@apigen/module/apigen/generator/frontend-copy/model/frontend-copy-model';

@Injectable({
    providedIn: 'root',
})
export class FrontendCopyService {
    endpoint: string;

    constructor(private httpClient: HttpClient, private uiPreloaderService: PreloaderService) {
        this.endpoint = 'http://apigen.hvlnet.net:8080/apigen/frontend/copy';
    }

    public copy(model: T): Observable<Boolean> {
        const converter = new JsonConvert();
        this.uiPreloaderService.show();

        return this.httpClient.post<HvlResponse<T>>(this.endpoint, converter.serialize(model, T)).pipe(
            map((data) => Boolean(data)),
            finalize(() => this.uiPreloaderService.hide()),
        );
    }
}
