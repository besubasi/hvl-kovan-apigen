import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastModule } from 'primeng/toast';
import { TableModule } from 'primeng/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ToolbarModule } from 'primeng/toolbar';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { RxTranslateModule } from '@rxweb/translate';
import { environment } from '../environments/environment';
import { MenuModule } from 'primeng/menu';

import { HvlMultiTranslateHttpLoader, HvlNgLanguageModule } from '@hvlng/framework-core/language';
import { PrimengSharedModule } from '@hvlng/framework-core/shared';
import { HvlBreadcrumbService, HvlMenuService, HvlNgFrameworkThemeModule } from '@hvlng/framework-theme';
import { HvlNgCoreModule, HvlValidNotationService } from '@hvlng/framework-bff/core';
import { HvlFormItemModule } from '@hvlng/framework-core/form';
import { HvlNgSecurityModule } from '@hvlng/framework-bff/security';
import { HvlNgBaseModule } from '@hvlng/framework-core/base';

import { UiPreloaderModule } from 'ui-shared';

import { ApigenAppRoutingModule } from '@apigen/apigen-app-routing.module';
import { ApigenRootComponent } from '@apigen/apigen-root.component';
import { ApigenMainComponent } from '@apigen/apigen-main.component';

export function ModuleHttpLoaderFactory(http: HttpClient) {
    return new HvlMultiTranslateHttpLoader(http, [
        { prefix: './assets/i18n/common/', suffix: '.json' },
        { prefix: './assets/i18n/', suffix: '/toast.json' },
        { prefix: './assets/i18n/', suffix: '/ui-shared.json' },
        { prefix: './assets/i18n/', suffix: '/apigen.json' },
    ]);
}

@NgModule({
    imports: [
        BrowserModule,
        ApigenAppRoutingModule,
        FormsModule,
        HttpClientModule,
        BrowserAnimationsModule,
        HvlNgSecurityModule.forRoot(),
        PrimengSharedModule,
        HvlNgFrameworkThemeModule,
        ToastModule,
        HvlNgCoreModule.forRoot(environment),
        TableModule,
        ToolbarModule,
        HvlFormItemModule,
        ReactiveFormsModule,
        UiPreloaderModule,
        HvlNgBaseModule.forRoot(),
        HvlNgLanguageModule.forRoot(),
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: ModuleHttpLoaderFactory,
                deps: [HttpClient],
            },
            isolate: false,
            extend: true,
        }),
        RxTranslateModule.forRoot({
            cacheLanguageWiseObject: true,
            filePath: 'assets/i18n/{{language-code}}/{{translation-name}}.json',
        }),
        MenuModule,
    ],
    declarations: [ApigenRootComponent, ApigenMainComponent],
    providers: [
        { provide: LocationStrategy, useClass: HashLocationStrategy },
        HvlMenuService,
        HvlBreadcrumbService,
        HvlValidNotationService,
    ],
    bootstrap: [ApigenRootComponent],
})
export class ApigenAppModule {}
