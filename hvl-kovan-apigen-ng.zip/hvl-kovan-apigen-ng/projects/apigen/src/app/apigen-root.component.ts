import { Component } from '@angular/core';

@Component({
    selector: 'apigen-root',
    templateUrl: './apigen-root.component.html',
})
export class ApigenRootComponent {}
