import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {
    HvlAccessdeniedComponent,
    HvlErrorComponent,
    HvlForbiddenComponent,
    HvlLoginComponent,
    HvlNotfoundComponent,
    HvlResetPasswordComponent,
    HvlVerificationComponent,
    HvlVerificationValidationComponent,
} from '@hvlng/framework-theme';

import { ApigenMainComponent } from '@apigen/apigen-main.component';

export const routes: Routes = [
    {
        path: '',
        children: [
            {
                path: '',
                component: ApigenMainComponent,
                children: [],
            },
            {
                path: 'apigen',
                component: ApigenMainComponent,
                loadChildren: () => import('./module/apigen/apigen.module').then((m) => m.ApigenModule),
            },
            { path: '500', component: HvlErrorComponent },
            { path: '404', component: HvlNotfoundComponent },
            { path: '403', component: HvlForbiddenComponent },
            { path: 'resetPassword', component: HvlResetPasswordComponent },
            { path: 'verification', component: HvlVerificationComponent },
            { path: 'verificationValidation', component: HvlVerificationValidationComponent },
            { path: '401', component: HvlAccessdeniedComponent },
            { path: 'login', component: HvlLoginComponent },
            { path: '**', redirectTo: '/404' },
        ],
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class ApigenAppRoutingModule {}
